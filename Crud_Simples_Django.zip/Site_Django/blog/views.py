from django.shortcuts import render

from blog.models import Carros

def index(request):
	data = {}
	data['db'] = Carros.objects.all()
	return render(request, 'index.html',data)


