from django.apps import AppConfig


class PerfilConfig(AppConfig):
    name = 'perfil'
